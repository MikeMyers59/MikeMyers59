# jquery-my-tooltip

Demo - https://shamilfrontend.github.io/jquery-my-tooltip/
